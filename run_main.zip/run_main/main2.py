import tkinter as tk
from tkinter import ttk, Scrollbar, Canvas, Frame, messagebox
import winreg
import urllib.parse
import os
import datetime
import json
import subprocess
import glob
import win32com.client 
import webbrowser

file_tags_dict = {}
file_paths = []
tag_entries = []
tag_categories = {}  # カテゴリを保持
category_entries = {}
search_inputs = {}
comment_entries = {}  # コメント欄を追加
file_comments = {}

# タグデータとカテゴリの保存・読み込み
TAG_FILE = 'file_tags.json'
CATEGORY_FILE = 'tag_categories.json'
COMMENT_FILE = 'file_comments.json'

def save_all():
    with open(TAG_FILE, 'w') as f:
        json.dump(file_tags_dict, f, ensure_ascii=False, indent=4)
    with open(CATEGORY_FILE, 'w') as f:
        json.dump(tag_categories, f, ensure_ascii=False, indent=4)
    with open(COMMENT_FILE, 'w') as f:
        json.dump(file_comments, f, ensure_ascii=False, indent=4)

def load_all():
    global file_tags_dict, tag_categories, file_comments
    try:
        with open(TAG_FILE, 'r') as f:
            file_tags_dict = json.load(f)
    except FileNotFoundError:
        file_tags_dict = {}
    try:
        with open(CATEGORY_FILE, 'r') as f:
            tag_categories = json.load(f)
    except FileNotFoundError:
        tag_categories = {}
    try:
        with open(COMMENT_FILE, 'r') as f:
            file_comments = json.load(f)
    except FileNotFoundError:
        file_comments = {}


def get_recent_office_files(app_name, version='16.0'):
    key_path = f'Software\\Microsoft\\Office\\{version}\\{app_name}\\User MRU'
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path) as user_key:
            for i in range(100):
                try:
                    subkey_name = winreg.EnumKey(user_key, i)
                    if "LiveId" in subkey_name:
                        full_key = f"{key_path}\\{subkey_name}\\File MRU"
                        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, full_key) as file_key:
                            recent_files = []
                            j = 0
                            while True:
                                try:
                                    value = winreg.EnumValue(file_key, j)
                                    data = value[1]
                                    if data.startswith('[F00000000]'):
                                        path = data.split('*', 2)[-1]
                                        recent_files.append(path)
                                    j += 1
                                except OSError:
                                    break
                            return recent_files
                except OSError:
                    break
    except FileNotFoundError:
        return []
    return []

def decode_sharepoint_url(url):
    return os.path.basename(urllib.parse.unquote(url.split('*', 2)[-1]))


def update_files():
    global file_paths, tag_entries, comment_entries
    def open_category_popup(path):
        popup = tk.Toplevel(root)
        popup.title("カテゴリからタグを選択")
        popup.geometry("800x600")

        check_vars = {}
        toggle_states = {}

        def add_selected_tags():
            selected_tags = [tag for tag, var in check_vars.items() if var.get()]
            for tag in selected_tags:
                file_tags_dict.setdefault(tag, [])
                if path not in file_tags_dict[tag]:
                    file_tags_dict[tag].append(path)
            save_all()
            popup.destroy()

        popup_inner = Frame(popup)
        popup_inner.pack(fill='both', expand=True)

        left_frame = Frame(popup_inner)
        left_frame.pack(side='left', fill='both', expand=True)

        canvas = Canvas(left_frame)
        scroll_y = Scrollbar(left_frame, orient='vertical', command=canvas.yview)
        scrollable_frame = Frame(canvas)

        scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scroll_y.set)

        canvas.pack(side='left', fill='both', expand=True)
        scroll_y.pack(side='right', fill='y')

        right_frame = Frame(popup_inner)
        right_frame.pack(side='left', fill='y', padx=10, pady=10)
        add_btn = tk.Button(right_frame, text="追加", command=add_selected_tags)
        add_btn.pack(anchor='n')

        def toggle_category(cat, content_frame, toggle_btn):
            if toggle_states[cat].get():
                content_frame.pack_forget()
                toggle_states[cat].set(False)
                toggle_btn.config(text='▶')
            else:
                content_frame.pack(fill='x')
                toggle_states[cat].set(True)
                toggle_btn.config(text='▼')

        categories = set(tag_categories.values())
        categories = {'未分類' if c is None or c == '' else c for c in categories}
        for cat in sorted(categories):
            
            cat_frame = Frame(scrollable_frame)
            cat_frame.pack(fill='x', pady=5)

            toggle_states[cat] = tk.BooleanVar(value=False)
            content_frame = Frame(cat_frame)  # カテゴリ名と同じフレームに属させる


            header = Frame(cat_frame)
            header.pack(fill='x')

            toggle_btn = tk.Button(header, text='▶', width=2, relief='flat', command=lambda c=cat, f=content_frame, b=None: toggle_category(c, f, b))
            toggle_btn.pack(side='left')
            # trick to capture button instance in lambda
            toggle_btn.config(command=lambda c=cat, f=content_frame, b=toggle_btn: toggle_category(c, f, b))

            cat_label = tk.Label(header, text=cat, fg='blue')
            cat_label.pack(side='left', anchor='w')

            for tag, category in tag_categories.items():
                category = '未分類' if category is None or category == '' else category
                if category == cat:
                    var = tk.BooleanVar()
                    check_vars[tag] = var
                    cb = tk.Checkbutton(content_frame, text=tag, variable=var)
                    cb.pack(anchor='w')



    try:
        days = int(days_entry.get())
    except ValueError:
        status_label.config(text="日数は整数で入力してください", fg="red")
        return
    file_paths.clear()
    tag_entries.clear()
    comment_entries.clear()
    for widget in list_frame.winfo_children():
        widget.destroy()

    today = datetime.datetime.now().date()
    recent_files = []
    for app in ['Excel', 'Word', 'PowerPoint']:
        recent_files.extend(get_recent_office_files(app))
    recent_dir = os.path.expandvars(r'%APPDATA%\\Microsoft\\Windows\\Recent')
    for shortcut_path in glob.glob(os.path.join(recent_dir, '*.lnk')):
        try:
            shell = win32com.client.Dispatch("WScript.Shell")
            shortcut = shell.CreateShortcut(shortcut_path)
            target_path = shortcut.Targetpath
            if target_path.lower().endswith('.pdf'):
                access_time = datetime.datetime.fromtimestamp(os.path.getatime(target_path))
                if (today - access_time.date()).days <= days:
                    recent_files.append(target_path)
        except Exception:
            continue

    for file_path in recent_files:
        try:
            last_access_time = datetime.datetime.fromtimestamp(os.path.getatime(file_path))
            if (today - last_access_time.date()).days > days:
                continue
        except FileNotFoundError:
            continue

        path = file_path
        if path.startswith("https://"):
            path = decode_sharepoint_url(path)
        already_tagged = any(path in paths for paths in file_tags_dict.values())
        if already_tagged:
            continue

        path_lower = path.lower()
        for tag in file_tags_dict.keys():
            tag_clean = tag.strip().lower()
            if tag_clean and tag_clean in path_lower:
                if path not in file_tags_dict[tag]:
                    file_tags_dict[tag].append(path)

        container = Frame(list_frame)
        container.pack(fill='x', padx=5, pady=5)

        row = Frame(container)
        row.pack(fill='x')

        entry = tk.Entry(row, width=80)
        entry.insert(0, path)
        entry.config(state='readonly')
        entry.pack(side='left', padx=5)

        tag1 = ttk.Combobox(row, width=15)
        tag2 = ttk.Combobox(row, width=15)
        tag1.pack(side='left', padx=3)
        tag2.pack(side='left')
        tag1.bind("<Button-1>", lambda e, cb=tag1: cb.configure(values=list(file_tags_dict.keys())))
        tag2.bind("<Button-1>", lambda e, cb=tag2: cb.configure(values=list(file_tags_dict.keys())))
        category_btn = tk.Button(row, text="カテゴリから選択", command=lambda p=path: open_category_popup(p))
        category_btn.pack(side='left', padx=3)

        if path.startswith("http"):
            open_btn = tk.Button(row, text="ファイルを開く", command=lambda p=path: webbrowser.open(p))
            locate_btn = tk.Button(row, text="ファイルの場所を開く", command=lambda p=path: webbrowser.open(p))
        else:
            open_btn = tk.Button(row, text="ファイルを開く", command=lambda p=path: os.startfile(p))
            locate_btn = tk.Button(row, text="ファイルの場所を開く", command=lambda p=path: subprocess.run(['explorer', '/select,', p]))

        open_btn.pack(side='left', padx=3)
        locate_btn.pack(side='left', padx=3)

        comment_entry = tk.Entry(container, width=120)
        comment_entry.insert(0, file_comments.get(path, ''))
        comment_entry.pack(fill='x', padx=5, pady=2)

        file_paths.append(path)
        tag_entries.append((tag1, tag2))
        comment_entries[path] = comment_entry


def save_tags():
    global file_tags_dict, tag_categories, file_comments
    for path, (tag_entry1, tag_entry2) in zip(file_paths, tag_entries):
        tag1 = tag_entry1.get().strip()
        tag2 = tag_entry2.get().strip()
        for tag in [tag1, tag2]:
            if tag:
                if tag not in file_tags_dict:
                    file_tags_dict[tag] = []
                if path not in file_tags_dict[tag]:
                    file_tags_dict[tag].append(path)
                if tag not in tag_categories:
                    tag_categories[tag] = None
        tag_entry1.delete(0, tk.END)
        tag_entry2.delete(0, tk.END)

        # コメントを保存
        comment = comment_entries.get(path)
        if comment:
            file_comments[path] = comment.get().strip()

    save_all()
    status_label.config(text="タグが保存されました！", fg="green")

def update_category_view():

    for widget in category_scrollable.winfo_children():
        widget.destroy()

    tags_sorted = sorted(file_tags_dict.keys(), key=lambda t: (tag_categories.get(t) is None, tag_categories.get(t, ''), t))
    category_entries.clear()
    category_groups = {}
    for tag in tags_sorted:
        category = tag_categories.get(tag)
        category_groups.setdefault(category, []).append(tag)

    for category, tags in sorted(category_groups.items(), key=lambda x: (x[0] is not None, str(x[0]))):
        frame = Frame(category_scrollable)
        frame.pack(fill='x', padx=5, pady=2)

        toggle_default = category is None
        toggle_var = tk.BooleanVar(value=toggle_default)

        label_frame = Frame(frame)
        label_frame.pack(fill='x')

        toggle_text = tk.StringVar()
        toggle_text.set('▼' if toggle_default else '▶')

        tag_rows = []

        def make_toggle_func(var, text, tag_list):
            def toggle():
                show = not var.get()
                var.set(show)
                text.set('▼' if show else '▶')
                for row in tag_list:
                    if show:
                        row.pack(fill='x', padx=10, pady=1)
                    else:
                        row.pack_forget()
            return toggle

        toggle_button = tk.Button(label_frame, textvariable=toggle_text, width=2)
        toggle_button.pack(side='left')

        label_text = category if category is not None else '（未分類）'
        label = tk.Label(label_frame, text=label_text, fg='blue')
        label.pack(side='left')

        toggle_button.configure(command=make_toggle_func(toggle_var, toggle_text, tag_rows))

        for tag in tags:
            row = Frame(frame)
            tk.Label(row, text=tag, width=30, anchor='w').pack(side='left')
            value = tag_categories.get(tag, '')
            entry = ttk.Combobox(row, width=30, values=sorted(set(tag_categories.values()) - {None}))
            entry.set(value if isinstance(value, str) else '')
            entry.pack(side='left', padx=5)
            category_entries[tag] = entry
            tag_rows.append(row)
            if toggle_default:
                row.pack(fill='x', padx=10, pady=1)

def save_categories():
    for tag, entry in category_entries.items():
        tag_categories[tag] = entry.get().strip() or None
    save_all()
    update_category_view()
    update_search_tab()

def setup_category_tab():
    global category_scrollable

    category_canvas = Canvas(tab3)
    category_scrollbar = Scrollbar(tab3, orient='vertical', command=category_canvas.yview)
    category_scrollable = Frame(category_canvas)

    category_scrollable.bind("<Configure>", lambda e: category_canvas.configure(scrollregion=category_canvas.bbox("all")))
    category_canvas.create_window((0, 0), window=category_scrollable, anchor="nw")
    category_canvas.configure(yscrollcommand=category_scrollbar.set)

    category_canvas.pack(side="left", fill="both", expand=True)
    category_scrollbar.pack(side="left", fill="y")

    save_cat_btn = tk.Button(tab3, text="カテゴリを保存", command=save_categories)
    save_cat_btn.pack(side="right", padx=10, pady=10)

def update_search_tab():
    for widget in search_dynamic_frame.winfo_children():
        widget.destroy()

    all_categories = sorted(set(cat for cat in tag_categories.values() if cat))
    search_inputs.clear()

    block_titles = ['グループ1', 'グループ2']

    # 横並び用の親フレーム
    outer_row_frame = Frame(search_dynamic_frame)
    outer_row_frame.pack(fill='x', padx=10, pady=5)

    for block_num in range(2):
        block_frame = Frame(outer_row_frame)
        block_frame.grid(row=0, column=block_num, padx=10, sticky='n')

        label = tk.Label(block_frame, text=block_titles[block_num], font=('Arial', 10, 'bold'))
        label.grid(row=0, column=0, columnspan=2, sticky='w')

        mode_var = tk.StringVar(value='AND')
        and_rb = tk.Radiobutton(block_frame, text='AND', variable=mode_var, value='AND')
        or_rb = tk.Radiobutton(block_frame, text='OR', variable=mode_var, value='OR')
        and_rb.grid(row=0, column=2, padx=5)
        or_rb.grid(row=0, column=3, padx=5)

        search_inputs[f'block_{block_num}_mode'] = mode_var

        for i in range(5):
            category_var = tk.StringVar()
            tag_var = tk.StringVar()

            category_box = ttk.Combobox(block_frame, width=20, values=all_categories, textvariable=category_var)
            category_box.grid(row=i+1, column=0, padx=2, pady=2)

            tag_box = ttk.Combobox(block_frame, width=30, textvariable=tag_var)
            tag_box.grid(row=i+1, column=1, padx=2, pady=2)

            def update_tags(event, cat_var=category_var, tag_cb=tag_box):
                selected = cat_var.get()
                tag_cb.configure(values=[t for t, c in tag_categories.items() if c == selected])

            category_box.bind("<<ComboboxSelected>>", update_tags)
            search_inputs[f'block_{block_num}_cat_{i}'] = tag_box

    # グループの右に結合方法を配置
    outer_mode_frame = Frame(outer_row_frame)
    outer_mode_frame.grid(row=0, column=2, padx=10, sticky='n')

    outer_label = tk.Label(outer_mode_frame, text="2つのグループの結合方法:", font=('Arial', 10))
    outer_label.pack(anchor='w')

    outer_mode_var = tk.StringVar(value='AND')
    outer_and = tk.Radiobutton(outer_mode_frame, text='AND', variable=outer_mode_var, value='AND')
    outer_or = tk.Radiobutton(outer_mode_frame, text='OR', variable=outer_mode_var, value='OR')
    outer_and.pack(anchor='w')
    outer_or.pack(anchor='w')

    search_inputs['outer_mode'] = outer_mode_var

def run_search():
    for widget in result_frame.winfo_children():
        widget.destroy()
    def open_category_popup_search(target_path):
        popup = tk.Toplevel(root)
        popup.title("カテゴリからタグを選択")
        popup.geometry("600x500")

        canvas = Canvas(popup)
        scroll_y = Scrollbar(popup, orient='vertical', command=canvas.yview)
        scrollable = Frame(canvas)

        scrollable.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=scrollable, anchor='nw')
        canvas.configure(yscrollcommand=scroll_y.set)

        canvas.pack(side='left', fill='both', expand=True)
        scroll_y.pack(side='right', fill='y')

        check_vars = {}
        toggle_states = {}

        def toggle(cat, frame, btn):
            if toggle_states[cat].get():
                frame.pack_forget()
                toggle_states[cat].set(False)
                btn.config(text='▶')
            else:
                frame.pack(fill='x')
                toggle_states[cat].set(True)
                btn.config(text='▼')
        categories = set(tag_categories.values())
        categories = {'未分類' if c is None or c == '' else c for c in categories}
        for cat in sorted(categories):
        
            cat_frame = Frame(scrollable)
            cat_frame.pack(fill='x', pady=3)

            toggle_states[cat] = tk.BooleanVar(value=False)
            content_frame = Frame(cat_frame)
            
            btn = tk.Button(cat_frame, text="▶", width=2)
            btn.pack(side='left')
            btn.config(command=lambda c=cat, f=content_frame, b=btn: toggle(c, f, b))

            label = tk.Label(cat_frame, text=cat, fg='blue')
            label.pack(side='left')

            for tag, c in tag_categories.items():
                normalized_c = '未分類' if c is None or c == '' else c
                if normalized_c == cat:
                    var = tk.BooleanVar()
                    check_vars[tag] = var
                    cb = tk.Checkbutton(content_frame, text=tag, variable=var)
                    cb.pack(anchor='w')

        def add_selected():
            selected = [tag for tag, var in check_vars.items() if var.get()]
            for tag in selected:
                file_tags_dict.setdefault(tag, [])
                if target_path not in file_tags_dict[tag]:
                    file_tags_dict[tag].append(target_path)
            save_all()
            run_search()
            popup.destroy()

        tk.Button(popup, text="追加", command=add_selected).pack(pady=5)
        
    def get_block_results(block_num):
        tags = []
        for i in range(5):
            tag_box = search_inputs.get(f'block_{block_num}_cat_{i}')
            if tag_box:
                tag = tag_box.get().strip()
                if tag:
                    tags.append(tag)
        if not tags:
            return None
        mode = search_inputs.get(f'block_{block_num}_mode').get()
        sets = [set(file_tags_dict.get(tag, [])) for tag in tags]
        return set.intersection(*sets) if mode == 'AND' else set.union(*sets)

    result1 = get_block_results(0)
    result2 = get_block_results(1)

    if result1 is None and result2 is None:
        return
    elif result1 is None:
        result = result2
    elif result2 is None:
        result = result1
    else:
        outer_mode = search_inputs.get('outer_mode').get()
        result = result1 & result2 if outer_mode == 'AND' else result1 | result2

    if not result:
        tk.Label(result_frame, text="該当するファイルはありませんでした。", fg='red').pack()
        return

    for path in result:
        container = Frame(result_frame)
        container.pack(fill='x', padx=5, pady=5)

        row = Frame(container)
        row.pack(fill='x')

        filename = os.path.basename(path)
        tk.Label(row, text=filename, width=30, anchor='w').pack(side='left', padx=2)

        path_var = tk.StringVar(value=path)
        path_entry = tk.Entry(row, width=60, textvariable=path_var, state='readonly')
        path_entry.pack(side='left', padx=5)

        def enable_edit(entry=path_entry):
            entry.config(state='normal')


        def save_edit(entry, var, old_path):
            new_path = var.get().strip()
            if new_path and new_path != old_path:
                for tag in file_tags_dict:
                    if old_path in file_tags_dict[tag]:
                        file_tags_dict[tag].remove(old_path)
                        if new_path not in file_tags_dict[tag]:
                            file_tags_dict[tag].append(new_path)
                if old_path in file_comments:
                    file_comments[new_path] = file_comments.pop(old_path)
                if old_path in comment_entries:
                    comment_entries[new_path] = comment_entries.pop(old_path)
                save_all()
            entry.config(state='readonly')
            run_search()




        edit_btn = tk.Button(row, text="編集", command=lambda e=path_entry: enable_edit(e))
        edit_btn.pack(side='left', padx=2)

        save_btn = tk.Button(row, text="登録", command=lambda e=path_entry, v=path_var, p=path: save_edit(e, v, p))

        save_btn.pack(side='left', padx=2)

        open_btn = tk.Button(row, text="ファイルを開く", command=lambda p=path: os.startfile(p))
        open_btn.pack(side='left', padx=2)

        locate_btn = tk.Button(row, text="ファイルの場所を開く", command=lambda p=path: subprocess.run(['explorer', '/select,', p]))
        locate_btn.pack(side='left', padx=2)
        
        cat_btn = tk.Button(row, text="カテゴリから追加", command=lambda p=path: open_category_popup_search(p))
        cat_btn.pack(side='left', padx=2)

        tags = [tag for tag, paths in file_tags_dict.items() if path in paths]
        for tag in tags:
            tag_btn = tk.Button(row, text=tag, command=lambda t=tag, p=path: tag_popup(t, p))
            tag_btn.pack(side='left', padx=2)

        tag_entry = tk.Entry(row, width=15)
        tag_entry.pack(side='left', padx=2)
        add_btn = tk.Button(row, text="追加", command=lambda e=tag_entry, p=path: add_tag(e, p))
        add_btn.pack(side='left', padx=2)
        
        comment_entry = tk.Entry(container, width=120)
        comment_entry.insert(0, file_comments.get(path, ''))
        comment_entry.pack(fill='x', padx=5, pady=2)

        def save_comment(p=path, e=comment_entry):
            file_comments[p] = e.get().strip()
            save_all()

        update_btn = tk.Button(container, text="コメント更新", command=save_comment)
        update_btn.pack(anchor='e', padx=5)

        comment_entries[path] = comment_entry
           
        result_frame.update_idletasks()
        result_canvas.config(scrollregion=result_canvas.bbox("all"))
    result_frame.update_idletasks()
    result_canvas.config(scrollregion=result_canvas.bbox("all"))


def open_file_popup(path):
    popup = tk.Toplevel(root)
    popup.title("ファイルをどうしますか？")
    popup.geometry("400x150")
    tk.Label(popup, text=path, wraplength=380).pack(pady=10)
    tk.Button(popup, text="ファイルを開く", command=lambda: [os.startfile(path), popup.destroy()]).pack(pady=5)
    tk.Button(popup, text="ファイルの場所を開く", command=lambda: [subprocess.run(['explorer', '/select,', path]), popup.destroy()]).pack(pady=5)

def remove_tag(tag, path):
    if tag in file_tags_dict:
        if path in file_tags_dict[tag]:
            file_tags_dict[tag].remove(path)
        # タグが空でも削除せず残す
        save_all()
        run_search()

def tag_popup(tag, path):
    popup = tk.Toplevel(root)
    popup.title("タグ操作")
    tk.Label(popup, text=f"'{tag}' をどうしますか？").pack(pady=10)
    tk.Button(popup, text="削除", command=lambda: [remove_tag(tag, path), popup.destroy()]).pack(pady=5)
    tk.Button(popup, text="キャンセル", command=popup.destroy).pack(pady=5)

def add_tag(entry, path):
    tag = entry.get().strip()
    if tag:
        file_tags_dict.setdefault(tag, []).append(path)
        if tag not in tag_categories:
            tag_categories[tag] = None
        save_all()
        run_search()

# Tkinter Setup
root = tk.Tk()
root.title("ファイルタグ管理")
root.geometry("1200x700")

status_label = tk.Label(root, text="")
status_label.pack(pady=5)

notebook = ttk.Notebook(root)
notebook.pack(fill='both', expand=True)

# タグ追加タブ
tab1 = Frame(notebook)
notebook.add(tab1, text="タグ追加")

update_btn = tk.Button(tab1, text="更新", command=update_files)
update_btn.pack(pady=5)

days_label = tk.Label(tab1, text="何日前まで表示：")
days_label.pack()
global days_entry
days_entry = tk.Entry(tab1, width=5)
days_entry.insert(0, "0")  # 初期値0日
days_entry.pack()

canvas = Canvas(tab1, height=400)

scroll_y = Scrollbar(tab1, orient='vertical', command=canvas.yview)
list_frame = Frame(canvas)
list_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
canvas.create_window((0, 0), window=list_frame, anchor='nw')
canvas.configure(yscrollcommand=scroll_y.set)
canvas.pack(side='left', fill='both', expand=True)
scroll_y.pack(side='right', fill='y')

save_btn = tk.Button(tab1, text="タグを保存", command=save_tags)
save_btn.pack(pady=5)

# タグ検索タブ
tab2 = Frame(notebook)
notebook.add(tab2, text="タグ検索")
search_dynamic_frame = Frame(tab2)
search_dynamic_frame.pack(fill='x', pady=10)

tk.Button(tab2, text="検索", command=run_search).pack(pady=5)


result_canvas = Canvas(tab2, xscrollcommand=lambda f, l: result_scroll_x.set(f, l))
result_scroll_y = Scrollbar(tab2, orient='vertical', command=result_canvas.yview)
result_scroll_x = Scrollbar(tab2, orient='horizontal', command=result_canvas.xview)
result_frame = Frame(result_canvas)
result_canvas.create_window((0, 0), window=result_frame, anchor='nw')
result_canvas.configure(yscrollcommand=result_scroll_y.set, xscrollcommand=result_scroll_x.set)

result_canvas.pack(side='left', fill='both', expand=True)
result_scroll_y.pack(side='right', fill='y')
result_scroll_x.pack(side='bottom', fill='x')
# タグカテゴリタブ
tab3 = Frame(notebook)
notebook.add(tab3, text="カテゴリ管理")
setup_category_tab()

load_all()
update_files()
update_category_view()
update_search_tab()

root.mainloop()
